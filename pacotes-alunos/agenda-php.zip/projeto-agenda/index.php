<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Agenda em PHP</title>
    <link rel="stylesheet" href="style/style.css">
</head>
<body>
    <main>
        <h1>Agenda em PHP</h1>
        
        <p>Exemplo de projeto que salva imagens em bancos de dados de maneira que não deixe a base MySQL pesada pelo uso de dados do tipo BLOB.</p>
        
        <p><a href="contato-incluir.php">&#x2795; Incluir novo contato</a></p>
        
        <table>
            <tr>
                <th>Foto</th>
                <th>Nome</th>
                <th>&#x2699;</th>
            </tr>
            <tr>
                <td><img src="fotos-banco/_semfoto.jpg" alt="Foto contato" class="miniatura"></td>
                <td>Fulano de Tal</td>
                <td><a href="contato-ver.php">&#x1F441;</a></td>
            </tr>
        </table>
    
    </main>
</body>
</html>