<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Visualização do Contato</title>
    <link rel="stylesheet" href="style/style.css">
</head>
<body>
    <main>
        <h1>Fulano de Tal</h1>
        <img src="fotos-banco/_semfoto.jpg" class="normal">
        <p>&#x260E; Telefone: <strong>(21)98333-2222</strong></p>
        <p>&#x1F4CD; Endereço: <strong>Rua sem nome, número 8</strong></p>

        <a href="index.php">&#x1F448; Voltar</a>
    </main>
</body>
</html>