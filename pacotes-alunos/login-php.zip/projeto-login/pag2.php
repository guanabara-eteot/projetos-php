<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Página 2</title>
    <link rel="stylesheet" href="style/style.css">
</head>
<body>
    <main>
        <h1>Página 2 - Liberada</h1>
        
        <p>Qualquer pessoa pode acessar essa página.</p>

        <p><a href="index.php">Voltar</a></p>
    </main>
</body>
</html>